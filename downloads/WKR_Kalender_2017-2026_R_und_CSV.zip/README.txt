WKR Kalender 2017-2026 - R-Skript und erzeugte CSV-Dateien
Regelversion 1.1.0, tatsaechlicher Kalenderstand vom 28.10.2026.

Inhalt:
  generate_calendar_de.R                 vollstaendiges R-Skript
  calendar_daily.csv                    25.564 Tageszeilen
  calendar_weekly.csv                     3.661 regionale Wochenzeilen
  datumlanderferienfeiertage.csv         21.234 erzeugte Verkaufstagszeilen
  SHA256SUMS.txt                         SHA-256 der vier Originaldateien

Die drei CSV-Dateien sind UTF-8 mit Semikolon als Trennzeichen und Dezimalkomma.
Enthalten sind Berlin, Brandenburg, Bremen, Niedersachsen, Nordrhein-Westfalen,
Sachsen-Anhalt und Thueringen, einschliesslich Halloween und Valentinstag.
Die CSVs sind bereits fertig berechnet und koennen direkt in Excel importiert werden.

R-Skript starten:
1. R installieren. Getestet: R 4.5.1 und jsonlite 2.0.0.
2. Einmal in R: install.packages("jsonlite", repos="https://cloud.r-project.org")
3. Im entpackten Ordner in PowerShell ausfuehren:
   Rscript generate_calendar_de.R --start-year 2017 --end-year 2026 --output kalender_neu
   Der Ausgabeordner muss neu sein. Fuer den Betrieb ist kein Docker erforderlich.

Das Skript laedt bei einem neuen Lauf aktuelle Quellensnapshots. Diese koennen
spaeter vom hier enthaltenen Kalenderstand abweichen. Rohantworten/Quellen-Cache
sind nicht in diesem ZIP enthalten. Ein optionaler Vergleich mit einer eigenen
Referenz ist mit --legacy PFAD_ZUR_CSV moeglich; die Referenz wird nicht veraendert.
Die manuelle Referenzdatei selbst ist nicht Bestandteil dieses Pakets.

Quellen und Attribution:
Schulferien: OpenHolidays API, https://www.openholidaysapi.org/ , CC BY 4.0
https://creativecommons.org/licenses/by/4.0/
Gesetzliche Feiertage: Nager.Date API, https://date.nager.at/
Eigene Bearbeitung: Einkaufsmerkmale, Ferienerweiterungen und Wochenaggregation.
Die OpenHolidays-Lizenz wird nicht pauschal auf die zweite Quelle uebertragen.
Oertliche bewegliche Ferientage sind nicht notwendigerweise vollstaendig erfasst;
belegte Zusatzferien koennen mit --extra-school PFAD_ZUR_CSV ergaenzt werden.

Dokumentation und Quellcode:
https://github.com/sayac007/-wkr-automotive-forecasting-lab
Siehe docs/calendar_generator_r.md fuer alle Regeln und Optionen.

Pruefen in PowerShell (Beispiel):
Get-FileHash -Algorithm SHA256 -LiteralPath .\generate_calendar_de.R
Das Ergebnis mit SHA256SUMS.txt vergleichen.
