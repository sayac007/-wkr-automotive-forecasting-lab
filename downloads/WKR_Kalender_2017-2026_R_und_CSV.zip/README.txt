WKR Deutschlandkalender, Regelversion 1.2.0, erstellt am 28.10.2026

16 Bundeslaender, 2017-2026, einschliesslich Halloween und Valentinstag.
calendar_daily.csv: vollstaendige Tagesdaten.
calendar_weekly.csv: regionale ISO-Wochen.
calendar_weekly_de.csv: bevoelkerungsgewichtete Deutschland-Wochen.
datumlanderferienfeiertage.csv: erzeugte Verkaufstagsdaten, keine Handreferenz.
CSV-Kalender: UTF-8, Semikolon, Dezimalkomma; NA bedeutet nicht definiert.
Bevoelkerungs-Eingabe-CSV: UTF-8, Komma; 16 Laender plus Deutschland.

Start (getestet R 4.5.1, jsonlite 2.0.0):
Einmal in R: install.packages("jsonlite", repos="https://cloud.r-project.org")
Dann in PowerShell im entpackten Ordner:
Rscript generate_calendar_de.R --start-year 2017 --end-year 2026 --output kalender_neu --population population_de_2025-12-31.csv
Das Ausgabeziel muss neu sein. Docker ist nicht erforderlich.
Ein neuer Lauf laedt aktuelle Kalenderquellen und kann spaeter andere Datenstaende
liefern. Rohantworten und manuelle Referenz sind nicht in diesem ZIP enthalten.

Wochenregeln:
O = Montag-Samstag ohne gesetzliche Feiertage des Landes (volle Woche: 6, 5, 4 ...).
F = Anzahl dieser Oeffnungstage mit Ferienmarkierung; Sonntage/Feiertage zaehlen nicht.
Die fruehere Kalenderzaehlung steht separat in Ferientage_Kalender.
w = Einwohner des Landes / Einwohner Deutschlands.
Ferientage_gewichtet = Summe(w * F).
Ladenoeffnungstage_gewichtet = Summe(w * O).
Ferienanteil_gewichtet = Summe(w * F/O).
Ferienanteil_aus_gewichteten_Tagen = Summe(w * F) / Summe(w * O).
Die beiden Anteilsdefinitionen sind verschieden und ausdruecklich getrennt.
Bei O=0 ist ein Anteil NA, nicht null. Unvollstaendige Randwochen sind markiert.

Gewichte: fester Destatis-Stichtag 31.12.2025, Deutschland 83.467.117 Personen,
exakt mit den 16 Laendern abgeglichen. Retrospektive Standardisierung, kein
historischer Point-in-time-Bevoelkerungsstand. Keine Umnormierung einer Teilmenge.
Feiertagsscope: landesweite Feiertage; kommunale Sonderfaelle nicht vollstaendig.
Mariae Himmelfahrt ist im Saarland landesweit, in Bayern nur oertlich Feiertag.
Der bayerische Teilanteil wird nicht erfunden oder als ganz Bayern angesetzt.
Lokale bewegliche Schulferientage koennen mit belegter --extra-school CSV ergaenzt werden.

Quellen:
Schulferien: OpenHolidays API, https://www.openholidaysapi.org/ , CC BY 4.0
https://creativecommons.org/licenses/by/4.0/
Gesetzliche Feiertage: Nager.Date API, https://date.nager.at/
Bevoelkerung: Statistisches Bundesamt (Destatis), GENESIS-Online, Tabellen
12411-0010 und 12411-0001; Abruf 28.10.2026; Datenlizenz by-2-0
https://www.govdata.de/dl-de/by-2-0 ; eigene Auswahl/Darstellung und Berechnung.
Original-URLs und Quellhashes in population_de_2025-12-31.provenance.json.
Die OpenHolidays-Lizenz wird nicht auf die anderen Quellen uebertragen.
Eigene Ableitungen: Einkaufsmerkmale, Ferienerweiterung und gewichtete Aggregation.

Quellcode und Fachregeln: https://github.com/sayac007/-wkr-automotive-forecasting-lab
Siehe docs/calendar_generator_r.md. Keine Modell- oder Umsatzschaetzung.
Die Dateien entsprechen dem wirklich ausgefuehrten Lauf; keine erfundenen Werte.
SHA256SUMS.txt enthaelt Pruefsummen aller Nutzdateien einschliesslich dieser Anleitung.
